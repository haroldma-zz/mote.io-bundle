console.log(window.location.host)

