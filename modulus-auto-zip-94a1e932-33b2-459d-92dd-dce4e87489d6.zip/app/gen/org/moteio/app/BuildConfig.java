/** Automatically generated file. DO NOT MODIFY */
package org.moteio.app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}